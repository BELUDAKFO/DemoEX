
"""
Веб-приложение для магазина игрушек МирИгрушек
"""

from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from functools import wraps

app = Flask(__name__, template_folder='web/templates', static_folder='web/static')
app.secret_key = 'toys_shop_secret_key_2026'

DB_PATH = 'data/toys_shop.db'

def get_db_connection():
    """Создание подключения к базе данных"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def login_required(f):
    """проверка авторизации авторизации"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Необходимо войти в систему', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    """проверка прав для администрации"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get('role') != 'Администратор':
            flash('Доступ запрещен', 'error')
            return redirect(url_for('products'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    """Главная страница - перенаправление на страницу входа"""
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Страница авторизации"""
    if request.method == 'POST':
        login_input = request.form.get('login')
        password = request.form.get('password')
        
        conn = get_db_connection()
        user = conn.execute('''
            SELECT u.*, r.role_name 
            FROM users u 
            JOIN roles r ON u.role_id = r.role_id 
            WHERE u.login = ? AND u.password = ?
        ''', (login_input, password)).fetchone()
        conn.close()
        
        if user:
            session['user_id'] = user['user_id']
            session['full_name'] = user['full_name']
            session['role'] = user['role_name']
            flash(f'Добро пожаловать, {user["full_name"]}!', 'success')
            return redirect(url_for('products'))
        else:
            flash('Неверный логин или пароль', 'error')
    
    return render_template('login.html')

@app.route('/guest')
def guest_login():
    """Вход как гость"""
    session['user_id'] = None
    session['full_name'] = 'Гость'
    session['role'] = 'Гость'
    return redirect(url_for('products'))

@app.route('/logout')
def logout():
    """Выход из системы"""
    session.clear()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('login'))

@app.route('/products')
def products():
    """Страница списка товаров"""
    conn = get_db_connection()
    
    # Получение параметров фильтрации и сортировки
    search = request.args.get('search', '')
    supplier_filter = request.args.get('supplier', '')
    sort_by = request.args.get('sort', '')
    
    # Базовый запрос
    query = '''
        SELECT p.*, s.supplier_name, m.manufacturer_name, c.category_name
        FROM products p
        JOIN suppliers s ON p.supplier_id = s.supplier_id
        JOIN manufacturers m ON p.manufacturer_id = m.manufacturer_id
        JOIN categories c ON p.category_id = c.category_id
        WHERE 1=1
    '''
    params = []
    
    # Применение поиска
    if search:
        query += ''' AND (
            p.product_name LIKE ? OR 
            p.article LIKE ? OR 
            p.description LIKE ? OR
            s.supplier_name LIKE ? OR
            m.manufacturer_name LIKE ? OR
            c.category_name LIKE ?
        )'''
        search_param = f'%{search}%'
        params.extend([search_param] * 6)
    
    # Применение фильтра по поставщику
    if supplier_filter:
        query += ' AND s.supplier_name = ?'
        params.append(supplier_filter)
    
    # Применение сортировки
    if sort_by == 'price_asc':
        query += ' ORDER BY p.price ASC'
    elif sort_by == 'price_desc':
        query += ' ORDER BY p.price DESC'
    elif sort_by == 'quantity_asc':
        query += ' ORDER BY p.quantity ASC'
    elif sort_by == 'quantity_desc':
        query += ' ORDER BY p.quantity DESC'
    else:
        query += ' ORDER BY p.product_id'
    
    products_list = conn.execute(query, params).fetchall()
    
    # Получение списка поставщиков для фильтра
    suppliers = conn.execute('SELECT DISTINCT supplier_name FROM suppliers ORDER BY supplier_name').fetchall()
    
    conn.close()
    
    # Проверка прав доступа
    role = session.get('role', 'Гость')
    can_filter = role in ['Менеджер', 'Администратор']
    can_edit = role == 'Администратор'
    
    return render_template('products.html', 
                         products=products_list, 
                         suppliers=suppliers,
                         can_filter=can_filter,
                         can_edit=can_edit,
                         search=search,
                         supplier_filter=supplier_filter,
                         sort_by=sort_by)

@app.route('/product/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_product():
    """Добавление нового товара"""
    if request.method == 'POST':
        article = request.form.get('article')
        product_name = request.form.get('product_name')
        unit = request.form.get('unit')
        price = request.form.get('price')
        supplier_id = request.form.get('supplier_id')
        manufacturer_id = request.form.get('manufacturer_id')
        category_id = request.form.get('category_id')
        discount = request.form.get('discount', 0)
        quantity = request.form.get('quantity', 0)
        description = request.form.get('description')
        photo = request.form.get('photo', 'picture.png')
        
        # Валидация данных
        if not all([article, product_name, unit, price, supplier_id, manufacturer_id, category_id]):
            flash('Заполните все обязательные поля', 'error')
            return redirect(url_for('add_product'))
        
        try:
            price = float(price)
            quantity = int(quantity)
            discount = int(discount)
            if price < 0 or quantity < 0 or discount < 0:
                raise ValueError
        except ValueError:
            flash('Цена, количество и скидка должны быть положительными числами', 'error')
            return redirect(url_for('add_product'))
        
        conn = get_db_connection()
        try:
            conn.execute('''
                INSERT INTO products (article, product_name, unit, price, supplier_id, 
                                    manufacturer_id, category_id, discount, quantity, description, photo)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (article, product_name, unit, price, supplier_id, manufacturer_id, 
                  category_id, discount, quantity, description, photo))
            conn.commit()
            flash('Товар успешно добавлен', 'success')
            return redirect(url_for('products'))
        except sqlite3.IntegrityError:
            flash('Товар с таким артикулом уже существует', 'error')
        finally:
            conn.close()
    
    # Получение справочников
    conn = get_db_connection()
    suppliers = conn.execute('SELECT * FROM suppliers').fetchall()
    manufacturers = conn.execute('SELECT * FROM manufacturers').fetchall()
    categories = conn.execute('SELECT * FROM categories').fetchall()
    conn.close()
    
    return render_template('product_form.html', 
                         product=None, 
                         suppliers=suppliers,
                         manufacturers=manufacturers,
                         categories=categories)

@app.route('/product/edit/<int:product_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_product(product_id):
    """Редактирование товара"""
    conn = get_db_connection()
    
    if request.method == 'POST':
        product_name = request.form.get('product_name')
        unit = request.form.get('unit')
        price = request.form.get('price')
        supplier_id = request.form.get('supplier_id')
        manufacturer_id = request.form.get('manufacturer_id')
        category_id = request.form.get('category_id')
        discount = request.form.get('discount', 0)
        quantity = request.form.get('quantity', 0)
        description = request.form.get('description')
        photo = request.form.get('photo')
        
        try:
            price = float(price)
            quantity = int(quantity)
            discount = int(discount)
            if price < 0 or quantity < 0 or discount < 0:
                raise ValueError
        except ValueError:
            flash('Цена, количество и скидка должны быть положительными числами', 'error')
            return redirect(url_for('edit_product', product_id=product_id))
        
        conn.execute('''
            UPDATE products 
            SET product_name=?, unit=?, price=?, supplier_id=?, manufacturer_id=?, 
                category_id=?, discount=?, quantity=?, description=?, photo=?
            WHERE product_id=?
        ''', (product_name, unit, price, supplier_id, manufacturer_id, category_id, 
              discount, quantity, description, photo, product_id))
        conn.commit()
        conn.close()
        flash('Товар успешно обновлен', 'success')
        return redirect(url_for('products'))
    
    product = conn.execute('SELECT * FROM products WHERE product_id = ?', (product_id,)).fetchone()
    suppliers = conn.execute('SELECT * FROM suppliers').fetchall()
    manufacturers = conn.execute('SELECT * FROM manufacturers').fetchall()
    categories = conn.execute('SELECT * FROM categories').fetchall()
    conn.close()
    
    return render_template('product_form.html', 
                         product=product,
                         suppliers=suppliers,
                         manufacturers=manufacturers,
                         categories=categories)

@app.route('/product/delete/<int:product_id>')
@login_required
@admin_required
def delete_product(product_id):
    """Удаление товара"""
    conn = get_db_connection()
    
    # Проверка наличия товара в заказах
    in_orders = conn.execute('''
        SELECT COUNT(*) as count FROM order_items WHERE product_id = ?
    ''', (product_id,)).fetchone()
    
    if in_orders['count'] > 0:
        flash('Невозможно удалить товар, который присутствует в заказах', 'error')
    else:
        conn.execute('DELETE FROM products WHERE product_id = ?', (product_id,))
        conn.commit()
        flash('Товар успешно удален', 'success')
    
    conn.close()
    return redirect(url_for('products'))

@app.route('/orders')
@login_required
def orders():
    """Страница списка заказов (для менеджеров и администраторов)"""
    role = session.get('role')
    if role not in ['Менеджер', 'Администратор']:
        flash('Доступ запрещен', 'error')
        return redirect(url_for('products'))
    
    conn = get_db_connection()
    orders_list = conn.execute('''
        SELECT o.*, u.full_name, pp.address
        FROM orders o
        LEFT JOIN users u ON o.user_id = u.user_id
        JOIN pickup_points pp ON o.point_id = pp.point_id
        ORDER BY o.order_id DESC
    ''').fetchall()
    conn.close()
    
    can_edit = role == 'Администратор'
    return render_template('orders.html', orders=orders_list, can_edit=can_edit)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
