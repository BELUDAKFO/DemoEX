
"""
Скрипт для создания и наполнения базы данных SQLite
"""

import sqlite3
import shutil
from pathlib import Path

# Создание подключения к базе данных
conn = sqlite3.connect('data/toys_shop.db')
cursor = conn.cursor()

# Создание таблиц 
cursor.execute('''
CREATE TABLE IF NOT EXISTS roles (
    role_id INTEGER PRIMARY KEY AUTOINCREMENT,
    role_name TEXT UNIQUE NOT NULL
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    role_id INTEGER NOT NULL,
    full_name TEXT NOT NULL,
    login TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS suppliers (
    supplier_id INTEGER PRIMARY KEY AUTOINCREMENT,
    supplier_name TEXT UNIQUE NOT NULL
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS manufacturers (
    manufacturer_id INTEGER PRIMARY KEY AUTOINCREMENT,
    manufacturer_name TEXT UNIQUE NOT NULL
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS categories (
    category_id INTEGER PRIMARY KEY AUTOINCREMENT,
    category_name TEXT UNIQUE NOT NULL
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS products (
    product_id INTEGER PRIMARY KEY AUTOINCREMENT,
    article TEXT UNIQUE NOT NULL,
    product_name TEXT NOT NULL,
    unit TEXT NOT NULL,
    price REAL NOT NULL,
    supplier_id INTEGER NOT NULL,
    manufacturer_id INTEGER NOT NULL,
    category_id INTEGER NOT NULL,
    discount INTEGER DEFAULT 0,
    quantity INTEGER DEFAULT 0,
    description TEXT,
    photo TEXT,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
    FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(manufacturer_id),
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS pickup_points (
    point_id INTEGER PRIMARY KEY AUTOINCREMENT,
    address TEXT UNIQUE NOT NULL
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS orders (
    order_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    order_date DATE NOT NULL,
    delivery_date DATE NOT NULL,
    point_id INTEGER NOT NULL,
    pickup_code INTEGER NOT NULL,
    status TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (point_id) REFERENCES pickup_points(point_id)
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS order_items (
    item_id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
)
''')

# Вставка ролей
roles_data = [
    ('Администратор',),
    ('Менеджер',),
    ('Авторизированный клиент',),
    ('Гость',)
]
cursor.executemany('INSERT OR IGNORE INTO roles (role_name) VALUES (?)', roles_data)

# Вставка пользователей
users_data = [
    (1, 'Ворсин Петр Евгеньевич', '94d5ous@gmail.com', 'uzWC67'),
    (1, 'Старикова Елена Павловна', 'uth4iz@mail.com', '2L6KZG'),
    (1, 'Одинцов Серафим Артёмович', 'yzls62@outlook.com', 'JlFRCZ'),
    (2, 'Михайлюк Анна Вячеславовна', '1diph5e@tutanota.com', '8ntwUp'),
    (2, 'Ситдикова Елена Анатольевна', 'tjde7c@yahoo.com', 'YOyhfR'),
    (2, 'Никифорова Весения Николаевна', 'wpmrc3do@tutanota.com', 'RSbvHv'),
    (3, 'Степанов Михаил Артёмович', '5d4zbu@tutanota.com', 'rwVDh9'),
    (3, 'Ворсин Петр Евгеньевич', 'ptec8ym@yahoo.com', 'LdNyos'),
    (3, 'Старикова Елена Павловна', '1qz4kw@mail.com', 'gynQMT'),
    (3, 'Сазонов Руслан Германович', '4np6se@mail.com', 'AtnDjr'),
]
cursor.executemany('INSERT OR IGNORE INTO users (role_id, full_name, login, password) VALUES (?, ?, ?, ?)', users_data)

# Вставка поставщиков
suppliers = ['Pikeshop', 'Playbig', 'Knauf', 'CHILITOY', 'Vinylon']
cursor.executemany('INSERT OR IGNORE INTO suppliers (supplier_name) VALUES (?)', [(s,) for s in suppliers])

# Вставка производителей
manufacturers = ['ABSпластик', 'BambiniFelici', 'Junion']
cursor.executemany('INSERT OR IGNORE INTO manufacturers (manufacturer_name) VALUES (?)', [(m,) for m in manufacturers])

# Вставка категорий
categories = ['Игровой набор', 'Конструктор', 'Детский музыкальный инструмент', 'Машинка']
cursor.executemany('INSERT OR IGNORE INTO categories (category_name) VALUES (?)', [(c,) for c in categories])

# Вставка товаров
products_data = [
    ('PMEZMH', 'Детский игровой набор машинок Щенячий патруль / Dogs mini . 9 героев + 9 инерфионных машинок', 'шт.', 1414, 1, 1, 1, 22, 50, 'Детский набор машинок с героями мультсериала «Щенячий патруль» подойдет как для мальчиков, так и для девочек. В детский набор входит 9 фигурок щенков спасателей.', '1.jpg'),
    ('BPV4MM', 'Конструктор Гарри Поттер Сова Букля 630 деталей совместим с lego harry potter, лего совместимый)', 'шт.', 771, 2, 1, 2, 15, 26, 'Коллекционная модель Букля состоит из множества потрасающих элементов, а также специального механизма внутри. С его помощью можно плавно поднимать-опускать крылья птицы.', '2.jpg'),
    ('JVL42J', 'Музыкальные инструменты для детей, ксилофон, барабаны, развивающие игрушки, игрушки для детей', 'шт.', 2750, 2, 2, 3, 15, 0, 'Откройте мир музыки для вашего ребенка с этой уникальной игрушкой! Это многофункциональное музыкальное чудо объединяет в себе всё, что нужно для творческого развития.', '3.jpg'),
    ('F895RB', 'Машинка игрушка диско шар светящаяся музыкальная', 'шт.', 368, 3, 1, 4, 6, 7, 'Светящаяся музыкальная машина с диско шаром переливается разными цветами, играет ритмичные мелодии, объезжает препятствия и крутится, поэтому с ней точно не будет скучно.', '4.jpg'),
    ('3XBOTN', 'Игровой набор Hot Wheels Action Loop Cyclone Challenge Track, с машинкой и удобным хранением, HTK16', 'шт.', 3426, 3, 2, 1, 10, 21, 'Игровой набор Hot Wheels Action Loop Cyclone Challenge Track - это уникальная игра, которая позволит вам испытать себя и своих друзей в скорости и ловкости. Этот набор состоит из металлической дорожки с циклоном, которая создает потрясающий эффект и добавляет дополнительную сложность в игру.', '5.jpg'),
    ('3L7RCZ', 'Игровой набор с деревянными машинками Стройплощадка Кран-Паркс, Junion', 'шт.', 7400, 3, 3, 1, 15, 0, 'Игровой набор «Стройплощадка Кран-Паркс Junion» — это большая игрушечная парковка с деревянными машинками и настоящим подъёмным краном, придуманная в Яндексе настоящими родителями.', '6.jpg'),
    ('S72AM3', 'Синтезатор детский с микрофоном 61 клавиша', 'шт.', 1749, 4, 3, 3, 10, 35, 'Откройте для ребенка дверь в мир музыки с детским синтезатором! Этот компактный инструмент с микрофоном станет верным другом для юных музыкантов, помогая им развивать творческий потенциал и получать удовольствие от игры.', '7.jpg'),
    ('2G3280', 'Деревянный игровой набор JUNION Стройплощадка "Кран-Паркс" с подъёмным, строительным краном и машинками, 18 предметов, подвижные элементы', 'шт.', 1624, 5, 3, 1, 9, 20, 'Игровой набор «Стройплощадка Кран-Паркс Junion» — это большая игрушечная парковка с деревянными машинками и настоящим подъёмным краном, придуманная в Яндексе настоящими родителями.', '8.jpg'),
    ('MIO8YV', 'Музыкальная игрушка интерактивная Пульт, детский прорезыватель для малышей', 'шт.', 305, 5, 2, 3, 9, 31, 'Музыкальная игрушка интерактивная Пульт, детский прорезыватель для малышей', '9.jpg'),
    ('UER2QD', 'Большой набор опытов и экспериментов для детей 14 в 1', 'шт.', 2506, 5, 2, 1, 8, 27, 'Большой набор опытов и экспериментов для детей 14 в 1', '10.jpg'),
]
cursor.executemany('INSERT OR IGNORE INTO products (article, product_name, unit, price, supplier_id, manufacturer_id, category_id, discount, quantity, description, photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', products_data)

# Вставка пунктов выдачи
pickup_points_data = [
    '420151, г. Лесной, ул. Вишневая, 32',
    '125061, г. Лесной, ул. Подгорная, 8',
    '630370, г. Лесной, ул. Шоссейная, 24',
    '400562, г. Лесной, ул. Зеленая, 32',
    '614510, г. Лесной, ул. Маяковского, 47',
    '410542, г. Лесной, ул. Светлая, 46',
    '620839, г. Лесной, ул. Цветочная, 8',
    '443890, г. Лесной, ул. Коммунистическая, 1',
    '603379, г. Лесной, ул. Спортивная, 46',
    '603721, г. Лесной, ул. Гоголя, 41',
    '410172, г. Лесной, ул. Северная, 13',
    '614611, г. Лесной, ул. Молодежная, 50',
    '454311, г.Лесной, ул. Новая, 19',
    '660007, г.Лесной, ул. Октябрьская, 19',
    '603036, г. Лесной, ул. Садовая, 4',
    '394060, г.Лесной, ул. Фрунзе, 43',
    '410661, г. Лесной, ул. Школьная, 50',
    '625590, г. Лесной, ул. Коммунистическая, 20',
    '625683, г. Лесной, ул. 8 Марта',
]
cursor.executemany('INSERT OR IGNORE INTO pickup_points (address) VALUES (?)', [(p,) for p in pickup_points_data])

# Вставка заказов
orders_data = [
    (7, '2025-02-27', '2025-04-20', 1, 901, 'Завершен'),
    (8, '2024-09-28', '2025-04-21', 11, 902, 'Завершен'),
    (9, '2025-03-21', '2025-04-22', 2, 903, 'Завершен'),
    (10, '2025-02-20', '2025-04-23', 11, 904, 'Завершен'),
    (7, '2025-03-17', '2025-04-24', 2, 905, 'Завершен'),
    (8, '2025-03-01', '2025-04-25', 15, 906, 'Завершен'),
    (9, '2025-03-20', '2025-04-26', 3, 907, 'Завершен'),
    (10, '2025-03-31', '2025-04-27', 19, 908, 'Новый'),
    (9, '2025-04-02', '2025-04-28', 5, 909, 'Новый'),
    (10, '2025-04-03', '2025-04-29', 19, 910, 'Новый'),
]
cursor.executemany('INSERT OR IGNORE INTO orders (user_id, order_date, delivery_date, point_id, pickup_code, status) VALUES (?, ?, ?, ?, ?, ?)', orders_data)

# Вставка товаров в заказах
order_items_data = [
    (1, 1, 2), (1, 2, 2),
    (2, 3, 1), (2, 4, 1),
    (3, 5, 10), (3, 6, 10),
    (4, 7, 5), (4, 8, 4),
    (5, 9, 2), (5, 10, 2),
    (6, 1, 2), (6, 2, 2),
    (7, 3, 1), (7, 4, 1),
    (8, 5, 10), (8, 6, 10),
    (9, 7, 5), (9, 8, 4),
    (10, 9, 2), (10, 10, 2),
]
cursor.executemany('INSERT OR IGNORE INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)', order_items_data)

# Копирование изображений
source_images = Path('/import')
target_images = Path('web/static/images')

for i in range(1, 11):
    src = source_images / f'{i}.JPG'
    dst = target_images / f'{i}.jpg'
    if src.exists():
        shutil.copy(src, dst)

# Копирование иконок и других изображений
for img in ['icon.ico', 'icon.jpg', 'icon.png', 'picture.png']:
    src = source_images / img
    dst = target_images / img
    if src.exists():
        shutil.copy(src, dst)

conn.commit()
conn.close()

print("База данных успешно создана и заполнена!")
print("Файл: data/toys_shop.db")
